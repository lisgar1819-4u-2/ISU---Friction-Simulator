var background = canvas.getContext("2d");

//Declaring Images for Background Image
var bg = new Image();
bg.src = "images/bg1.png";

//Function for canvas
function drawBG() {
  //draw our background before our actual object
  background.drawImage(bg, 0, 0);
  //redraw constantly
  requestAnimationFrame(drawBG);
}
//put this function to work when the page loads up.
drawBG();