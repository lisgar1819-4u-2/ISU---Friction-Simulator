//displays numbers on the screen below the canvas
function displayText(Fa, Kg, Fn, uk, us, type, current, friction, time, Fnet, a, v) {

  document.querySelector("#resultFa").innerHTML = Fa.toFixed(2) + " N";
  document.querySelector("#resultKg").innerHTML = Kg.toFixed(2) + " Kg";

  document.querySelector("#resultF").innerHTML = type + friction.toFixed(2) + " N";
  document.querySelector("#resultCurrentF").innerHTML = current + Fa.toFixed(2) + " N";
  document.querySelector("#resultTime").innerHTML = time.toFixed(2) + " seconds";

  //************* For testing/ debuggin purposes
  //document.querySelector("#resultFn").innerHTML = Fn.toFixed(2) + " N [up]";
  //document.querySelector("#resultFg").innerHTML = Fn.toFixed(2) + " N [down]";
  //document.querySelector("#resultuk").innerHTML = uk.toFixed(2);
  //document.querySelector("#resultus").innerHTML = us.toFixed(2);
  //document.querySelector("#resultFnet").innerHTML = Fnet + " N";
  //document.querySelector("#resultA").innerHTML = a + " m/s^2";
  //document.querySelector("#resultV").innerHTML = v + " m/s";

}