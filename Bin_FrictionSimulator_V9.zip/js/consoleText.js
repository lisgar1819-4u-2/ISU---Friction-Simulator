//To use this, right-click "inspect" and a white box should appear
//Select the "Console" tab to the right of "Elements"
function consoleText(Fa, Kg, Fn, uk, us, type, friction, time, Fnet, a, v) {
  //displays numbers on the console for debugging
  console.log("Applied Force (Fa): " + Fa.toFixed(2));
  console.log("Mass (kg):" + Kg.toFixed(2));
  console.log("Time (s): " + time.toFixed(1));
  console.log(" Fn: " + Fn.toFixed(2));
  //Since |Fg| = |Fn|
  console.log(" Fg: " + Fn.toFixed(2));
  console.log("uk: " + uk.toFixed(1));
  console.log("us: " + us.toFixed(1));
  console.log("Fnet: " + Fnet.toFixed(1) + "N");
  console.log("acceleration: " + a.toFixed(1));
  console.log("velocity: " + v.toFixed(1));
  console.log("\n");
}