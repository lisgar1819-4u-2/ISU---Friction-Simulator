const uk = 0.10
const us = 0.15
const g = 9.81

function calculate() {
  //receiving input from range sliders
  let Fa = parseInt(document.querySelector("#valueFa").value);
  let Kg = parseInt(document.querySelector("#valueKg").value);
  let time = parseInt(document.querySelector("#valueTime").value);

  //Since |Fg| = |Fn|
  let Fn = Kg * g;
  //Solving for Kinetic and Static Friction
  let Fk = uk * Fn;
  let Fs = us * Fn;
  //Choosing the type of friction:
  let type; //type is a string,
  let larger; // if applied force is larger than static then true else false.
  let friction; //actual friction depends on if it exceeds applied force or not
  let Fnet = 0;
  let a = 0;
  let v = 0;
  let arrow_v = 0;
  let arrow_a = 0;
  let currentF;
  //arrow position behind object
  arrow_x = (canvas.width / 3).toFixed(0) - 91;
  arrow_y = (canvas.height / 2).toFixed(0) - 14;

  if (Fa < Fs) {
    friction = Fs; //if not enough to overide static friction
    type = "Max Static Friction:      ";
    currentF = "Current Static Friction: "
    larger = false;
    //Fnet, a, and v should be 0 because the object does not move
    //draw(time, a, v);
  } else if (Fa > Fs) {
    friction = Fk; //if force is bigger than static friction
    type = "Kinetic Friction (Fk):  ";
    currentF = "Applied Force (Fa):  ";
    larger = true;
    //Total Net Force
    Fnet = Fa + friction * (-1);
    //acceleration
    a = Fnet / Kg;
    //velocity
    v = 0;
  }

  //display text on console for Debugging (see consoleText.js)
  console.log("Checking to see if values are consistent...");
  consoleText(Fa, Kg, Fn, uk, us, type, friction, time, Fnet, a, v);
  //display text on screen (see displayText.js)
  displayText(Fa, Kg, Fn, uk, us, type, currentF, friction, time, Fnet, a, v);

  //********************* Draw from calculations ****************************
  var timeLimit = false; //bool when the timer reaches the user's time input
  /* When this happens, the object is no longer pushed.
  Therefore, Fnet is negative and equal to its friction, since Fa is 0.
  _a means negative accerleration. This allows the object to stop.
  */
  let _a = (friction * -1) / Kg;

  /*this function calls another function, which is "stop();". It
 changes the bool timeLimit to true after # seconds of the
  inputed time. "time" * 1000 because this function works with milliseconds
  and we want to change it to seconds.*/
  let idStop = setTimeout(stop, time * 1000);

  function stop() {
    timeLimit = true; //Time limit is reached. Slow down
  }

  /*Display time function puts a timer on the canvas*/
  let seconds = 0;
  let idTimer = setInterval(timer, 100) //executes 10 times per second
  function timer() {
    seconds += 0.1;
  }

  //This is my draw() function.
  function draw() {
    context.drawImage(cover_blue, 382, 235);
    //Draw the square with velocity and acceleration
    context.drawImage(object, px, py);
    //our arrow is behind the object.
    context.drawImage(arrow, arrow_x, arrow_y);

    //Velocity of OUR OBJECT
    v += a;
    px += (v - 1 / 2 * a) / 60; //v*t - 1/2*a*t^ is full the full equation


    //arrow's motion
    arrow_a = a;
    arrow_v += arrow_a;
    arrow_x += (arrow_v - 1 / 2 * a) / 60;

    if (larger) {
      context.drawImage(cover_brown, 932, 296);
      context.drawImage(speeding, 950, 320);
      display_forces_numbers();
    }

    if (!larger) {
      context.drawImage(cover_brown, 932, 296);
      context.drawImage(still, 950, 320);
      //the reason why I don't use the display_forces_diagrams();
      //is because that function displays Fk but I want to display Fs now.
      //see below to understand.
      context.fillText("Fn", 1005, 320);
      context.fillText("Fg", 1005, 490);
      context.fillText("Fs", 930, 380);
      context.fillText("Fa", 1077, 380);
    }

    //Putting the timer on the canvas
    context.fillText("Timer:", canvas.width / 3 - 125, canvas.height - 20);
    context.fillText(seconds.toFixed(2), canvas.width / 3, canvas.height - 20);
    context.fillText(" s", canvas.width / 3 + 65, canvas.height - 20);

    //if time limit is reached, then change to negative acceleration.
    if (timeLimit) {
      a = _a;

      //make arrow stop but object keeps on moving and slowing down.
      arrow_a = 0;
      arrow_v = 0;

      //stop our timers
      clearInterval(idTimer);
      clearTimeout(idStop);



      //force diagram for slowing down when time limit is reached
      //do not draw if it is not moving because Fstatic > Fa
      if (larger) {
        context.drawImage(cover_brown, 932, 296);
        context.drawImage(slowing, 950, 320);
        display_forces_numbers();
      }

    }

    //If it completely slowed down to a stop, or velocity is 0, then
    //make the acceleration 0 or else it would turn
    //and go in the other direction.
    if (v <= 0) {
      a = 0;

      //force diagram for object not moving
      //context.drawImage(still, 950, 291);

      if (larger) {
        context.drawImage(cover_brown, 932, 296);
        context.drawImage(still2, 950, 320);
        display_forces_numbers();
      }

    }

    requestAnimationFrame(draw);
  }
  draw();
}