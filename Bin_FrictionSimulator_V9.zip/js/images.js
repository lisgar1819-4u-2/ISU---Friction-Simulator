//****************** Object
var canvas = document.getElementById("canvas");
var context = canvas.getContext("2d");
context.font = "30px Courier New";
context.fillStyle = "rgb(255, 255, 255)";

var object = new Image();
object.src = "images/object.png";

//Positions x and y
var px = (canvas.width / 3).toFixed(0) - 34;
var py = (canvas.height / 2).toFixed(0) - 12;

//****************** Force Diagram
var still = new Image(); //if forces are equal. Not moving or at constant speed
still.src = "images/still.png";

var speeding = new Image(); //accelerating. Fa > Friction
speeding.src = "images/speeding.png";

var slowing = new Image(); //slowing down. Friction > Fa
slowing.src = "images/slowing.png";

var still2 = new Image(); // when there are no forces acting
still2.src = "images/none.png";

var cover_brown = new Image();
cover_brown.src = "images/cover_brown.png";

var cover_blue = new Image();
cover_blue.src = "images/cover_blue.png";

var arrow = new Image(); //arrow for hand pushing the object
arrow.src = "images/arrow.png";

//display the numbers on the force diagrams
function display_forces_numbers() {
  context.fillText("Fn", 1005, 320);
  context.fillText("Fg", 1005, 490);
  context.fillText("Fk", 930, 380);
  context.fillText("Fa", 1077, 380);
}